/*
These scripts will be included globally as part of the backend.

=require mediamanager.popup.js

*/
